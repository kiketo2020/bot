import type { ChatCompletionRequestMessage } from 'openai';

export async function sendMessage(messages: ChatCompletionRequestMessage[]): Promise<string> {
  const res = await fetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages }),
  });
  if (!res.ok) throw new Error('Chat API error');
  const data = await res.json();
  return data.choices[0].message.content;
}