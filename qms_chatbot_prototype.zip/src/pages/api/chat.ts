import type { NextApiRequest, NextApiResponse } from 'next';
import { Configuration, OpenAIApi } from 'openai';

if (!process.env.OPENAI_API_KEY) {
  throw new Error('Missing OPENAI_API_KEY');
}

const openai = new OpenAIApi(new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
}));

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  try {
    const { messages, model = 'gpt-4', temperature = 0.2 } = req.body;
    const response = await openai.createChatCompletion({
      model,
      messages,
      temperature,
    });
    res.status(200).json(response.data);
  } catch (err: any) {
    console.error('OpenAI error:', err);
    res.status(500).json({ error: err.message });
  }
}