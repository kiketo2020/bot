'use client';

import React from 'react';
import { FixedSizeList as List } from 'react-window';
import ReactMarkdown from 'react-markdown';
import rehypeHighlight from 'rehype-highlight';
import type { ChatCompletionRequestMessage } from 'openai';

interface ChatContainerProps {
  messages: ChatCompletionRequestMessage[];
  isLoading: boolean;
}

export function ChatContainer({ messages, isLoading }: ChatContainerProps) {
  const height = typeof window !== 'undefined' ? window.innerHeight - 200 : 500;
  return (
    <List
      height={height}
      itemCount={messages.length}
      itemSize={100}
      width="100%"
    >
      {({ index, style }) => {
        const msg = messages[index];
        return (
          <div
            key={index}
            style={style}
            className={`p-4 break-words ${msg.role === 'assistant' ? 'bg-gray-800 text-white' : 'bg-gray-200 text-black'}`}
          >
            <ReactMarkdown rehypePlugins={[rehypeHighlight]}>
              {msg.content}
            </ReactMarkdown>
          </div>
        );
      }}
    </List>
  );
}