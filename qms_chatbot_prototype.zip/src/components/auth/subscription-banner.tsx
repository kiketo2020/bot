'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { User } from '@supabase/supabase-js';

interface SubscriptionBannerProps {
  user: User;
}

export function SubscriptionBanner({ user }: SubscriptionBannerProps) {
  const [plan, setPlan] = useState<string>('free');

  useEffect(() => {
    async function fetchPlan() {
      const { data, error } = await supabase
        .from('subscriptions')
        .select('plan')
        .eq('user_id', user.id)
        .single();
      if (!error && data) {
        setPlan(data.plan);
      }
    }
    if (user) fetchPlan();
  }, [user]);

  if (plan === 'free') {
    return (
      <div className="bg-yellow-600 text-black p-2 text-center">
        You’re on the Free tier. Upgrade to get unlimited chat and export features!
      </div>
    );
  }
  return null;
}